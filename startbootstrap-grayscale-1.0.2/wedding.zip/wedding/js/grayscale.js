
// jQuery to collapse the navbar on scroll
$(window).scroll(function () {
    if ($(".navbar").offset().top > 50) {
        $(".navbar-fixed-top").addClass("top-nav-collapse");
    } else {
        $(".navbar-fixed-top").removeClass("top-nav-collapse");
    }
});

// jQuery for page scrolling feature - requires jQuery Easing plugin
$(function () {
    $('a.page-scroll').bind('click', function (event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top
        }, 1500, 'easeInOutExpo');
        event.preventDefault();
    });
});

// Closes the Responsive Menu on Menu Item Click
$('.navbar-collapse ul li a').click(function () {
    $('.navbar-toggle:visible').click();
});

// Google Maps Scripts
// When the window has finished loading create our google map below
google.maps.event.addDomListener(window, 'load', init);

function init() {
    // Basic options for a simple Google Map
    // For more options see: https://developers.google.com/maps/documentation/javascript/reference#MapOptions
    var mapOptions = {
        // How zoomed in you want the map to start at (always required)
        zoom: 15,
        // The latitude and longitude to center the map (always required)
        center: new google.maps.LatLng(40.6700, -73.9400), // New York

        // Disables the default Google Maps UI components
        disableDefaultUI: true,
        scrollwheel: false,
        draggable: false,
        // How you would like to style the map. 
        // This is where you would paste any style found on Snazzy Maps.
        styles: [{
                "featureType": "water",
                "elementType": "geometry",
                "stylers": [{
                        "color": "#000000"
                    }, {
                        "lightness": 17
                    }]
            }, {
                "featureType": "landscape",
                "elementType": "geometry",
                "stylers": [{
                        "color": "#000000"
                    }, {
                        "lightness": 20
                    }]
            }, {
                "featureType": "road.highway",
                "elementType": "geometry.fill",
                "stylers": [{
                        "color": "#000000"
                    }, {
                        "lightness": 17
                    }]
            }, {
                "featureType": "road.highway",
                "elementType": "geometry.stroke",
                "stylers": [{
                        "color": "#000000"
                    }, {
                        "lightness": 29
                    }, {
                        "weight": 0.2
                    }]
            }, {
                "featureType": "road.arterial",
                "elementType": "geometry",
                "stylers": [{
                        "color": "#000000"
                    }, {
                        "lightness": 18
                    }]
            }, {
                "featureType": "road.local",
                "elementType": "geometry",
                "stylers": [{
                        "color": "#000000"
                    }, {
                        "lightness": 16
                    }]
            }, {
                "featureType": "poi",
                "elementType": "geometry",
                "stylers": [{
                        "color": "#000000"
                    }, {
                        "lightness": 21
                    }]
            }, {
                "elementType": "labels.text.stroke",
                "stylers": [{
                        "visibility": "on"
                    }, {
                        "color": "#000000"
                    }, {
                        "lightness": 16
                    }]
            }, {
                "elementType": "labels.text.fill",
                "stylers": [{
                        "saturation": 36
                    }, {
                        "color": "#000000"
                    }, {
                        "lightness": 40
                    }]
            }, {
                "elementType": "labels.icon",
                "stylers": [{
                        "visibility": "off"
                    }]
            }, {
                "featureType": "transit",
                "elementType": "geometry",
                "stylers": [{
                        "color": "#000000"
                    }, {
                        "lightness": 19
                    }]
            }, {
                "featureType": "administrative",
                "elementType": "geometry.fill",
                "stylers": [{
                        "color": "#000000"
                    }, {
                        "lightness": 20
                    }]
            }, {
                "featureType": "administrative",
                "elementType": "geometry.stroke",
                "stylers": [{
                        "color": "#000000"
                    }, {
                        "lightness": 17
                    }, {
                        "weight": 1.2
                    }]
            }]
    };

    // Get the HTML DOM element that will contain your map 
    // We are using a div with id="map" seen below in the <body>
    var mapElement = document.getElementById('map');

    // Create the Google Map using out element and options defined above
    var map = new google.maps.Map(mapElement, mapOptions);

    // Custom Map Marker Icon - Customize the map-marker.png file to customize your icon
    var image = 'img/map-marker.png';
    var myLatLng = new google.maps.LatLng(40.6700, -73.9400);
    var beachMarker = new google.maps.Marker({
        position: myLatLng,
        map: map,
        icon: image
    });


}

// set the date we're counting down to
var target_date = new Date('Dec, 12, 2015').getTime();

// variables for time units
var days, hours, minutes, seconds;

// get tag element
var countdown = document.getElementById('countdown');

// update the tag with id "countdown" every 1 second
setInterval(function () {

    // find the amount of "seconds" between now and target
    var current_date = new Date().getTime();
    var seconds_left = (target_date - current_date) / 1000;

    // do some time calculations
    days = parseInt(seconds_left / 86400);
    seconds_left = seconds_left % 86400;

    hours = parseInt(seconds_left / 3600);
    seconds_left = seconds_left % 3600;

    minutes = parseInt(seconds_left / 60);
    seconds = parseInt(seconds_left % 60);

    // format countdown string + set tag value
    //countdown.innerHTML = '<span class="days">' + days + ' <b>Days</b></span> <span class="hours">' + hours + ' <b>Hours</b></span> <span class="minutes">'
    //        + minutes + ' <b>Minutes</b></span> <span class="seconds">' + seconds + ' <b>Seconds</b></span>';
    //countdown.innerHTML = '<span class="days"' + days + '</span><span class="hours"' + hours + '</span><span class="seconds"' + seconds + '</span>';

    //countdown.innerHTML = '<span class="days">' + days + '</span> <span class="hours">' + hours + ' </span> <span class="minutes">'
    //       + minutes + ' </span> <span class="seconds">' + seconds + ' </span>';

    //countdown.innerHTML = '<a><i class="fa fa-3x timer">' + days + '</i></a><a><i class="fa fa-heart fa-3x timer">' + hours + '</i></a><a><i class="fa fa-heart fa-3x timer">' + seconds + '</i></a>' +
    //        '</br><span class="timer">Days</span><span class="timer">Hours</span><span class="timer">Seconds</span>';

    countdown.innerHTML = '<div class="row text-center timer">'+
                '<div class="row col-lg-1 col-xs-1"></div>'+
                '<div class="row">' +
                '<a class="header col-lg-2 col-xs-3">' +
                '<i class="fa">' + days + '</i><h4>Days</h5></a>'+
                '<div>' +

                '<div class="row">' +
                '<a class="header col-lg-2 col-xs-1">' +
                '<i class="fa fa-heart white-heart"></i></a>'+
                '<div>' +
                
                '<div class="row">' +
                '<a class="header col-lg-2 col-xs-2">'+
                '<i class="fa">' + hours + '</i><h4 >Hours</h5></a>'+
                '<div>' +
                
                '<div class="row">' +
                '<a class="header col-lg-2 col-xs-1">' +
                '<i class="fa fa-heart white-heart"></i></a>'+
                '<div>' +
                
                 '<div class="row">' +
                '<a class="header col-lg-2 col-xs-1">'+
                '<i class="fa">' + seconds + '</i><h4>Seconds</h5></a>'+
                '<div>' +
                
                '<div class="row col-lg-1 col-xs-1"></div>' +
                '</div>';


}, 1000);

    